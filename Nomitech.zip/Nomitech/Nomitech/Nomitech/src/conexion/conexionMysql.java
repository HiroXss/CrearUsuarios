/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

/**
 *
 * @author Atun
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexionMysql {
    private static final String URL = "jdbc:mysql://localhost:3306/crearusuarios";
    private static final String USUARIO = "root"; 
    private static final String CONTRASENA = ""; 

    public static Connection conectar() {
        Connection conexion = null;
        try {
            conexion = (Connection) DriverManager.getConnection(URL, USUARIO, CONTRASENA);
            System.out.println("Conexión Establecida.");
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return conexion;
    }

    // Método para cerrar la conexión, si es necesario
    public static void cerrarConexion(Connection conexion) {
        if (conexion != null) {
            try {
                conexion.close();
                System.out.println("Conexión cerrada.");
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }  
}




